/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import Model.Cliente;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.event.ActionEvent;

/**
 *
 * @author Ildevana
 */
@ManagedBean
public class ClienteController {
    
    private Cliente cliente;
    List<Cliente> clientes;
    
    public ClienteController(){
        this.cliente = new Cliente(1, "Fabio", 33);
    }
    
    public void saveClient(ActionEvent event){
        Cliente c = new Cliente(1, "Fabio", 33);
        c.saveClient(c);
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    public List<Cliente> findAll(){
        Cliente cliente = new Cliente();
        return cliente.findAll();
    }
}
