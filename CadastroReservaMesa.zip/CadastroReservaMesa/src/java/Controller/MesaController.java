/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import Model.Mesa;
import javax.faces.bean.ManagedBean;
import javax.faces.event.ActionEvent;

/**
 *
 * @author Ildevana
 */
@ManagedBean
public class MesaController {
    private Mesa mesa;
    
     public MesaController(){
        this.mesa = new Mesa(1, 6);
     }
        public void saveMesa(ActionEvent event){
        Mesa m = new Mesa(1,6);
        m.saveMesa(m);
    }

    public Mesa getMesa() {
        return mesa;
    }

    public void setCliente(Mesa mesa) {
        this.mesa = mesa;
    }
    }

