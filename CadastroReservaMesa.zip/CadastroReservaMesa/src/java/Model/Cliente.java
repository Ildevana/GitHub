/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author Ildevana
 */
public class Cliente {
    
    protected EntityManager em;
    
    private int idCliente;
    private String nome;
    private String email;
    private int telefone;
    private int senha;
    
    public Cliente(){}
    
    public Cliente(int idCliente, String nome, int senha) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.senha = senha;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public int getTelefone() {
        return telefone;
    }

    public int getSenha() {
        return senha;
    }
    
    public void saveClient(Cliente c){
        
    }
    
    public List<Cliente> findAll(){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("CadastroReservasMesaPU");
        em = emf.createEntityManager();
        Query query = em.createQuery("SELECT c FROM CLIENTE c");
        return query.getResultList();
    }
}
