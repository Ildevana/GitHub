import java.util.HashSet;


public class stopList {
	
	public HashSet<String> list;
	
	public stopList(HashSet<String> list) {
	this.list = list;	
	}
	
	public HashSet<String> getList(){
		return list;
		
	}
	

}
